﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Services;
using System.Data.SqlClient;
using System.Data;

namespace WebServicess
{
    /// <summary>
    /// Summary description for WebServicess
    /// </summary>
    [WebService(Namespace = "http://tempuri.org/")]
    [WebServiceBinding(ConformsTo = WsiProfiles.BasicProfile1_1)]
    [System.ComponentModel.ToolboxItem(false)]
    // To allow this Web Service to be called from script, using ASP.NET AJAX, uncomment the following line. 
    // [System.Web.Script.Services.ScriptService]
    public class WebServicess : System.Web.Services.WebService
    {

       
            [WebMethod]
            public String create(String name, int Salary, String Depatment, String Designation)
            {
                SqlConnection con = new SqlConnection(@"Data Source=PG-PUN-103\SQLEXPRESS;Initial Catalog=Join_Example;Integrated Security=True");
                SqlCommand cmd = new SqlCommand("insert into EmpDetails values('" + name + "','" + Salary + "','" + Depatment + "','" + Designation + "')", con);
                con.Open();
                cmd.ExecuteNonQuery();
                con.Close();
                return "Data has been inserted";
            }



            [WebMethod]
            public String delete(String name)
            {
                SqlConnection con = new SqlConnection(@"Data Source=PG-PUN-103\SQLEXPRESS;Initial Catalog=Join_Example;Integrated Security=True");
                SqlCommand cmd = new SqlCommand("delete from EmpDetails where EmployeeName='" + name + "'", con);
                con.Open();
                cmd.ExecuteNonQuery();
                con.Close();
                return "Data has been Deleted";
            }



            [WebMethod]
            public String Update(String name, int salary)
            {
                SqlConnection con = new SqlConnection(@"Data Source=PG-PUN-103\SQLEXPRESS;Initial Catalog=Join_Example;Integrated Security=True");
                SqlCommand cmd = new SqlCommand("update EmpDetails set Salary=" + salary + " where EmployeeName='" + name + "'", con);
                con.Open();
                cmd.ExecuteNonQuery();
                con.Close();
                return "Data has been Updated ";
            }



            [WebMethod]
            public String Show()
            {
                SqlConnection con = new SqlConnection(@"Data Source=PG-PUN-103\SQLEXPRESS;Initial Catalog=Join_Example;Integrated Security=True");
                SqlCommand cmd = new SqlCommand("select * from EmpDetails", con);
                con.Open();
                cmd.ExecuteNonQuery();
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                DataSet ds = new DataSet();
                da.Fill(ds);
                con.Close();
                string str = ds.GetXml();
                return str;
            }
        }
    }

